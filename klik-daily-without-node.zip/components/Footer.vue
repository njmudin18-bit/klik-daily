<template>
	<div>
		<v-footer
	      :absolute="fixed"
	      app
	      class="justify-center"
	   >
      	<span>Copyright &copy; {{ new Date().getFullYear() }} | {{ footerTitle }}.</span>
    	</v-footer>
   </div>
</template>
<script>
  	export default {
    	data () {
      	return {
        		fixed: false,
        		footerTitle: 'Najmudin',
      	}
    	}
   };
</script>