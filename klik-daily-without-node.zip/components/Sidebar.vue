<template>
	<div>
		<v-navigation-drawer
         v-model="drawer"
         :mini-variant="miniVariant"
         :clipped="clipped"
         fixed
         app
      >
         <v-list>
            <v-list-item
            v-for="(item, i) in items"
            :key="i"
            :to="item.to"
            router
            exact
            >
               <v-list-item-action>
                  <v-icon>{{ item.icon }}</v-icon>
               </v-list-item-action>
               <v-list-item-content>
                  <v-list-item-title v-text="item.title" />
               </v-list-item-content>
            </v-list-item>
         </v-list>
      </v-navigation-drawer>
	</div>
</template>
<script>
   export default {
      data () {
         return {

            clipped: false,
            drawer: false,
            items: [
               {
                  icon: 'mdi-clipboard-plus',
                  title: 'Input Product',
                  to: '/'
               },
               {
                  icon: 'mdi-clipboard-text',
                  title: 'Detail Product',
                  to: '/product'
               },
               /*{
                  icon: 'mdi-chart-bubble',
                  title: 'Inspire',
                  to: '/inspire'
               }*/
            ],
            miniVariant: false,
         }
      }
   };
</script>