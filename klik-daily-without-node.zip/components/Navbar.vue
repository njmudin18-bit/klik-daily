<template>
   <div>
      <v-app-bar
         :clipped-left="clipped"
         fixed
         app
      >
         <v-app-bar-nav-icon @click.stop="drawer = !drawer" />
         <v-toolbar-title v-text="title" @click="goDashboard" style="cursor: pointer" />
         <v-spacer />
      </v-app-bar>   
   </div>
</template>
<script>
   export default {
      data () {
         return {
            drawer: false,
            clipped: false,
            fixed: false,
            right: true,
            rightDrawer: false,
            title: 'Klik Daily',

            clipped: false,
            drawer: false,
            items: [
               {
                  icon: 'mdi-apps',
                  title: 'Welcome',
                  to: '/'
               },
               {
                  icon: 'mdi-chart-bubble',
                  title: 'Product',
                  to: '/product'
               },
               {
                  icon: 'mdi-chart-bubble',
                  title: 'Inspire',
                  to: '/inspire'
               }
            ],
            miniVariant: false,
         }
      },

      methods: {
         goDashboard() {
            this.$router.push('/');
         }
      }
   };
</script>