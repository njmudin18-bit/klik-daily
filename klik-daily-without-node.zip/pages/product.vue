<template>
   <div id="product">

      <Navbar />

      <v-container class="">
         <v-row justify="center" align="center">
            <v-col cols="12" sm="12" md="4" class="images">
               <v-carousel hide-delimiters>
                  <v-carousel-item
                     v-for="(item,i) in items"
                     :key="i"
                     :src="item.src"
                  ></v-carousel-item>
              </v-carousel>

              <v-layout row wrap class="shared noted">
                  <v-col cols="6" sm="6" md="6" class="border-right">
                     Share:   <v-icon>mdi-facebook</v-icon> 
                              <v-icon>mdi-twitter</v-icon>
                              <v-icon>mdi-pinterest</v-icon>
                              <v-icon>mdi-facebook-messenger</v-icon>
                  </v-col>
                  <v-col cols="6" sm="6" md="6">
                     <v-icon @click="content = !content">mdi-heart-outline</v-icon> Favorit (23,3RB)
                  </v-col>
              </v-layout>
            </v-col>
            <v-col cols="12" sm="12" md="8" class="description">
               <div class="header">
                  <h3 class="main-header">a Clearance SALE PRESTO 7L GRANITE</h3>
               </div>
               <div class="sub-header">
                  <span class="left-text">
                     <span class="mini">{{rating}}</span>
                     <v-rating
                        v-model="rating"
                        background-color="red lighten-3"
                        color="red"
                        half-increments
                        hover
                        large
                     ></v-rating>
                  </span>
                  |<span class="center-text">1,8RB Penilaian</span>|
                  <span class="right-text">8,8RB Terjual</span>
               </div>
               <div class="prices">
                  <span class="money">Rp6.900</span>
               </div>
               
               <v-layout row wrap class="groceries">
                  <v-col cols="5" sm="5" md="2">
                     <span class="left-gro">Grosir</span>
                  </v-col>
                  <v-col cols="7" sm="7" md="10">
                     <span class="right-gro">Beli (>=10) Rp6.000</span>
                     <span class="right-gro-det" @click="openPopup" style="margin-left: 30px;">Selengkapnya ></span>
                  </v-col>
               </v-layout>

               <!-- <v-layout row wrap class="colors">
                  <v-col cols="5" sm="5" md="2">
                     <span class="left-gro form-text-short">Warna</span>
                  </v-col>
                  <v-col cols="7" sm="7" md="10" class="example ex1">
                     
                        <v-radio-group
                           v-model="row"
                           row
                        >
                           <label class="radio">
                              <v-radio
                                label="White Pearl"
                                value="radio-1"
                              ></v-radio>
                           </label>
                           <label class="radio">
                              <v-radio
                                label="Red Suns"
                                value="radio-2"
                              ></v-radio>
                           </label>
                        </v-radio-group>
                     
                  </v-col>
               </v-layout> -->

               <v-layout row wrap class="quantity">
                  <v-col cols="5" sm="5" md="2">
                     <span class="left-gro">Kuantitas</span>
                  </v-col>
                  <v-col cols="7" sm="7" md="10">
                     <v-text-field
                        v-model="quantity"
                        class="quantitys"
                        :min="minQuantitys"
                        readonly
                        >
                        <v-icon
                           slot="append"
                           color="grey"
                           @click="plus"
                        >
                           mdi-plus
                        </v-icon>
                        <v-icon
                           slot="prepend"
                           color="grey"
                           @click="minus"
                           :disabled="quantity <= 0"
                        >
                           mdi-minus
                        </v-icon>
                    </v-text-field>
                  </v-col>
               </v-layout>

               <v-layout row wrap class="quantity button-group">
                  <v-col cols="12" sm="12" md="12">
                     <v-btn
                        class="btn btn-product btn-cart"
                        outlined
                        depressed
                     >
                        <v-icon>mdi-cart-outline</v-icon>
                        Masukan Keranjang
                     </v-btn>
                     <v-btn
                        class="btn btn-product btn-orange"
                        depressed
                      >
                        Beli Sekarang
                     </v-btn>
                  </v-col>
               </v-layout>

               <v-divider style="margin-top: 20px; margin-bottom: 20px;"></v-divider>

               <v-layout row wrap class="noted">
                  <v-col cols="4" sm="3" md="3" class="noted-det">
                     <span class="tooltiper v-tooltip-open" v-tooltip.bottom-start="'Pengembalian gratis* dan praktis s/d 7 hari setelah barang diterima'">
                        <v-icon>
                           mdi-backup-restore
                        </v-icon>
                        7 Hr Pengembalian
                     </span>
                  </v-col>
                  <v-col cols="4" sm="3" md="3" class="noted-det">
                     <span class="tooltiper v-tooltip-open" v-tooltip.bottom-start="'Jaminan 100% original atau Uang kembali 2 kali lipat'">
                        <v-icon>
                           mdi-shield-outline
                        </v-icon>
                        100% Ori
                     </span>
                  </v-col>
                  <v-col cols="4" sm="3" md="3" class="noted-det">
                     <span class="tooltiper v-tooltip-open" v-tooltip.bottom-start="'Gratis Ongkir Spesial pada semua produk dengan min. belanja lebih rendah'">
                        <v-icon>
                           mdi-car-estate
                        </v-icon>
                        Gratis Ongkir
                     </span>
                  </v-col>
               </v-layout>
               
            </v-col>
         </v-row>
      </v-container>

      <Footer />

      <!-- DIALOG -->
      <v-dialog
         v-model="dialog"
         persistent
         max-width="360"
      >
         <v-card>
            <v-card-title class="headline">
               Grosir
            </v-card-title>
            <v-card-text>
               <v-layout row wrap class="modal-header-text">
                  <v-col cols="4" sm="4" md="4">Kuantitas</v-col>
                  <v-col cols="4" sm="4" md="4">Harga Satuan</v-col>
                  <v-col cols="4" sm="4" md="4">Hemat</v-col>
               </v-layout>
               <v-layout row wrap class="modal-content-text">
                  <v-col cols="4" sm="4" md="4">≥ 10</v-col>
                  <v-col cols="4" sm="4" md="4" class="text-orange">Rp6.000</v-col>
                  <v-col cols="4" sm="4" md="4">Rp900</v-col>
               </v-layout>
            </v-card-text>
            <v-card-actions>
               <v-spacer></v-spacer>
               <v-btn
                  color="grey"
                  text
                  @click="dialog = false"
                  depressed
                  outlined
               >
                  Close
               </v-btn>
            </v-card-actions>
         </v-card>
      </v-dialog>

   </div>
</template>

<script>
   import Navbar from '../components/Navbar';
   import Footer from '../components/Footer';

   export default {
      components: {
         Navbar,
         Footer,
      },
      data () {
         return {
            rating: 4,
            items: [
               { src: 'https://cdn.shopify.com/s/files/1/0813/5969/products/62557302_2418872758333176_3513462915412456338_n_1024x1024_1aa0394b-4d01-4d37-bfec-721ea1608d4d_1024x1024.jpg?v=1591433285'},
               { src: 'https://cdn.shopify.com/s/files/1/0813/5969/products/62557302_2418872758333176_3513462915412456338_n_1024x1024_1aa0394b-4d01-4d37-bfec-721ea1608d4d_1024x1024.jpg?v=1591433285' },
               { src: 'https://cdn.shopify.com/s/files/1/0813/5969/products/62557302_2418872758333176_3513462915412456338_n_1024x1024_1aa0394b-4d01-4d37-bfec-721ea1608d4d_1024x1024.jpg?v=1591433285' },
               { src: 'https://cdn.shopify.com/s/files/1/0813/5969/products/62557302_2418872758333176_3513462915412456338_n_1024x1024_1aa0394b-4d01-4d37-bfec-721ea1608d4d_1024x1024.jpg?v=1591433285' },
            ],
            dialog: false,
            row: null,
            headTitle: 'Product Details',
            quantity: 1,
            minQuantitys: 0
         }
      },

      head () {
         return {
            title: this.headTitle,
            meta: [
               {
                  hid: 'description',
                  name: 'description a',
                  content: 'Product'
               }
            ]
         }
      },

      methods: {
         openPopup() {
            this.dialog = true;
         },
         plus() {
            this.quantity = this.quantity + 1;
         },
         minus() {
            this.quantity = this.quantity - 1;
         }
      },
      watch: {
         
      }
   };
</script>

<style type="text/css">
   div#product {
      width: 1188px;
      /*background-color: #eff0f5;*/
      margin: auto;
      padding-left: 0!important;
      padding-right: 0!important;
      padding-bottom: 24px;
      overflow: hidden;
      box-shadow: 0px 3px 1px -2px rgba(0, 0, 0, 0.2), 0px 2px 2px 0px rgba(0, 0, 0, 0.14), 0px 1px 5px 0px rgba(0, 0, 0, 0.12);
   }

   .quantitys input {
      text-align: center;
   }

   .quantitys .v-input__prepend-outer{
      border: 1px solid rgba(0,0,0,.09);
      cursor: pointer;
   }

   .quantitys .v-input__append-inner{
      border: 1px solid rgba(0,0,0,.09);
      cursor: pointer;
      padding-left: 0px !important;
   }

   .quantitys .v-input__slot{
      width: 80px;
      position: initial;
   }

   .quantitys .v-text-field__slot{
      border: 1px solid rgba(0,0,0,.09);
      margin-right: 10px;
   }

   .quantitys.v-text-field{
      padding-top: 0px !important;
      margin-top: 0px !important;
   }

   .noted-det {
      cursor: pointer;
   }

   .colors .v-input--selection-controls {
      margin-top: 0px;
      padding-top: 0px;
   }

   .form-text-short {
      margin-top: 20px;
   }

   .shared {
      padding: 20px 15px;
      font-size: 14px;
   }

   .text-orange{
      color: #ee4d2d;
   }

   .border-right{
      border-right: 1px solid grey;
   }

   .colors {
      margin-top: 1rem;
      padding: 0 1.25rem;
   }

   .groceries {
      margin-top: 1.5625rem;
      padding: 0 1.25rem;
   }

   .noted {
      margin-top: 1.5625rem;
      padding: 0 1.25rem;
      font-size: 14px;
   }

   .noted .theme--light.v-icon {
      color: #ee4d2d;
   }

   .quantity {
      margin-top: 1rem;
      padding: 0 1.25rem;
   }

   .right-gro-det {
      margin-left: 20px;
      color: #05a;
      text-transform: capitalize;
      -webkit-flex-shrink: 0;
      -ms-flex-negative: 0;
      flex-shrink: 0;
      font-size: .875rem;
      cursor: pointer;
   }

   .modal-content-text {
      color: #222;
   }

   .description {
      padding: 0 40px;
   }

   .header{
      display: -webkit-box;
       text-overflow: ellipsis;
       -webkit-box-orient: vertical;
       -webkit-line-clamp: 2;
       font-weight: 500;
       margin: 0;
       vertical-align: sub;
       max-height: 3rem;
       line-height: 1.5rem;
       overflow: hidden;
       max-width: 41.5625rem;
       font-size: 1.25rem;
       word-wrap: break-word;
   }

   .sub-header{
      margin-top: 15px;
      margin-bottom: 15px;
      display: flex;
   }

   span.mini{
      margin-right: 10px;
      text-decoration: underline;
   }

   span.left-text {
      margin-right: 20px;
      display: flex;
   }

   span.center-text {
      margin-right: 20px;
      margin-left: 20px;
   }

   span.right-text {
      margin-left: 20px;
   }

   .v-application--is-ltr .v-rating .v-icon{
      font-size: 20px !important;
      padding: 0;
   }

   .prices{
      padding: 15px 20px;
      background: #fafafa;
   }

   .money{
      font-size: 1.875rem;
      font-weight: 500;
      color: #ee4d2d;
   }

   .left-gro {
      color: #757575;
      width: 110px; 
      text-transform: capitalize;
      -webkit-flex-shrink: 0;
      -ms-flex-negative: 0;
      flex-shrink: 0;
      -webkit-box-align: center;
      -webkit-align-items: center;
      -moz-box-align: center;
      -ms-flex-align: center;
      align-items: center;
   }

   span.right-gro {
      font-size: .875rem;
   }

   .btn.btn-product {
      width: 210px;
      height: 50px !important;
      margin-right: 20px;
   }

   .btn-product .v-btn__content{
      font-size: 12px;
   }

   .btn-orange {
      background: #e2492b !important;
      box-shadow: inset 0 2px 1px 0 rgba(0,0,0,.05);
      color: #fff !important;
   }

   .btn-cart{
      background: rgba(255,87,34,.1) !important;
      border: 1px solid #ee4d2d !important;
      box-shadow: 0 1px 1px 0 rgba(0,0,0,.03) !important;
      color: #e2492b !important;
   }

   .tooltip {
      display: block !important;
      z-index: 10000;
   }

   .tooltip .tooltip-inner {
      background: #fff;
      border: 1px solid rgba(0, 0, 0, 0.12);
      color: rgba(0,0,0,.8);
      border-radius: 2px;
      padding: 20px 10px 20px;
      font-size: 13px;
      line-height: 20px;
      font-family: "Roboto", sans-serif;
      width: 70%;
   }

   .tooltip .tooltip-arrow {
      width: 0;
      height: 0;
      border-style: solid;
      position: absolute;
      margin: 5px;
      border-color: black;
      z-index: 1;
   }

   .tooltip[x-placement^="top"] {
       margin-bottom: 5px;
   }

   .tooltip[x-placement^="top"] .tooltip-arrow {
      border-width: 5px 5px 0 5px;
      border-left-color: transparent !important;
      border-right-color: transparent !important;
      border-bottom-color: transparent !important;
      bottom: -5px;
      left: calc(50% - 5px);
      margin-top: 0;
      margin-bottom: 0;
   }

   .tooltip[x-placement^="bottom"] {
      margin-top: 5px;
   }

   .tooltip[x-placement^="bottom"] .tooltip-arrow {
      border-width: 0 5px 5px 5px;
       border-left-color: transparent !important;
      border-right-color: transparent !important;
      border-top-color: transparent !important;
      top: -5px;
      left: calc(50% - 5px);
      margin-top: 0;
      margin-bottom: 0;
   }

   .tooltip[x-placement^="right"] {
      margin-left: 5px;
   }

   .tooltip[x-placement^="right"] .tooltip-arrow {
      border-width: 5px 5px 5px 0;
      border-left-color: transparent !important;
      border-top-color: transparent !important;
      border-bottom-color: transparent !important;
      left: -5px;
      top: calc(50% - 5px);
      margin-left: 0;
      margin-right: 0;
   }

   .tooltip[x-placement^="left"] {
      margin-right: 5px;
   }

   .tooltip[x-placement^="left"] .tooltip-arrow {
      border-width: 5px 0 5px 5px;
      border-top-color: transparent !important;
      border-right-color: transparent !important;
      border-bottom-color: transparent !important;
      right: -5px;
      top: calc(50% - 5px);
      margin-left: 0;
      margin-right: 0;
   }

   .tooltip.popover .popover-inner {
      background: #f9f9f9;
      color: black;
      padding: 24px;
      border-radius: 5px;
      box-shadow: 0 5px 30px rgba(black, .1);
   }

   .tooltip.popover .popover-arrow {
     border-color: #f9f9f9;
   }

   .tooltip[aria-hidden='true'] {
      visibility: hidden;
      opacity: 0;
      transition: opacity .15s, visibility .15s;
   }

   .tooltip[aria-hidden='false'] {
      visibility: visible;
      opacity: 1;
      transition: opacity .15s;
   }
</style>