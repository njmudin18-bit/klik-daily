<template>
   <div id="daftar">

      <Navbar />
      
      <!-- <Sidebar /> -->

      <v-row justify="center" align="center">
        <v-col cols="12" sm="12" md="12">

            <h5 class="title">Create Order</h5>
            <!-- {{employees}} -->
            <v-card
              class="mx-auto"
              max-width="100%"
            >
              <v-card-text>
                
                <!-- EMPLOYEE NAME -->
                <v-row
                  justify="space-between"
                >
                  <v-col
                    cols="12"
                    md="4"
                  >
                    <v-card-title>Detail</v-card-title>
                  </v-col>

                  <v-col
                    cols="12"
                    md="6"
                  >
                    <label class="label-text">Name<span color="red darken-3">*</span></label>
                    <v-select
                      v-model="employeeName"
                      :items="employees"
                      item-text="employee_name"
                      item-value="id"
                      outlined
                      placeholder="Name"
                    ></v-select>
                  </v-col>

                  <v-col
                    cols="12"
                    md="2"
                  ></v-col>
                </v-row>
                <!-- EMPLOYEE NAME END -->

                <!-- DISTRIBUTION CENTER -->
                <v-row
                  justify="space-between"
                >

                  <v-col
                    cols="12"
                    md="4"
                  ></v-col>

                  <v-col
                    cols="12"
                    md="4"
                  >
                    <label class="label-text">Distribution Center
                      <span color="red darken-3">*</span>
                    </label>
                    <v-select
                      v-model="dcName"
                      :items="itemsDC"
                      item-text="name"
                      item-value="value"
                      outlined
                      placeholder="Distribution Center"
                      v-if="employeeName !== ''"
                    ></v-select>

                    <v-select
                      v-model="dcName"
                      outlined
                      placeholder="Distribution Center"
                      v-if="employeeName == ''"
                    ></v-select>
                  </v-col>

                  <v-col
                    cols="12"
                    md="4"
                  ></v-col>
                </v-row>
                <!-- DISTRIBUTION CENTER END -->

                <!-- PAYMENT TYPE -->
                <v-row
                  justify="space-between"
                  v-if="employeeName !== '' && dcName !== ''"
                >
                  <v-col
                    cols="12"
                    md="4"
                  ></v-col>

                  <v-col
                    cols="12"
                    md="4"
                  >
                    <label class="label-text">Payment Type
                      <span color="red darken-3">*</span>
                    </label>
                    <v-select
                      v-model="paymentType"
                      :items="itemsPT"
                      item-text="name"
                      item-value="value"
                      outlined
                      placeholder="Payment Type"
                    ></v-select>
                  </v-col>

                  <v-col
                    cols="12"
                    md="4"
                  >
                    <label class="label-text">Expired Date
                      <span color="red darken-3">*</span>
                    </label>
                    <v-menu
                      v-model="menu2"
                      :close-on-content-click="false"
                      :nudge-right="40"
                      transition="scale-transition"
                      offset-y
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on, attrs }">
                        <v-text-field
                          v-model="date"
                          placeholder="Expired Date"
                          readonly
                          v-bind="attrs"
                          v-on="on"
                          outlined
                        ></v-text-field>
                      </template>
                      <v-date-picker
                        v-model="date"
                        :min="new Date().toISOString().substr(0, 10)"
                        @input="menu2 = false"
                      ></v-date-picker>
                    </v-menu>
                  </v-col>
                </v-row>
                <!-- PAYMENT TYPE END -->

                <!-- NOTES -->
                <v-row
                  justify="space-between"
                  v-if="employeeName !== '' && dcName !== ''"
                >
                  <v-col
                    cols="12"
                    md="4"
                  >
                  </v-col>

                  <v-col
                    cols="12"
                    md="6"
                  >
                    <label class="label-text">Notes</label>
                    <v-textarea
                      outlined
                      v-model="notes"
                    ></v-textarea>
                  </v-col>

                  <v-col
                    cols="12"
                    md="2"
                  ></v-col>
                </v-row>
                <!-- NOTES END -->
              </v-card-text>

              <v-divider v-if="employeeName !== '' && dcName !== ''"></v-divider>

              <v-card-text
                v-if="employeeName !== '' && dcName !== ''"
              >
                <span v-for="(textField, i) in textFields" :key="i">
                  <!-- PRODUCTS & UNIT -->
                  <v-row
                    justify="space-between"
                  >
                    <v-col
                      cols="12"
                      md="4"
                    >
                      <v-card-title
                      v-if="textField === 0"
                      >
                      Products
                      </v-card-title>

                      {{i}} - 
                      <!--{{textFields.length}}-
                      {{itemsUnit}} -->

                      <v-btn 
                        fab 
                        @click="remove(i)" 
                        class="error btn-delete"
                        x-small
                        depressed
                        v-if="textField > 0"
                      >
                        <v-icon>mdi-minus</v-icon>
                      </v-btn>
                    </v-col>

                    <v-col
                      cols="12"
                      md="6"
                    >
                      <label class="label-text">Product<span color="red darken-3">*</span></label>
                      <span style="display:flex;">
                        <v-select
                          v-model="productName"
                          :items="itemsProducts"
                          item-text="product_name"
                          item-value="id"
                          outlined
                          placeholder="Product Name"
                          @change="getUnit"
                        ></v-select><!-- @input="getUnit" @change="getUnit" -->
                      </span>
                    </v-col>

                    <v-col
                      cols="12"
                      md="2"
                    >
                      <label class="label-text">Unit<span color="red darken-3">*</span></label>
                      <v-select
                        v-model="unitName"
                        :items="itemsUnit"
                        item-text="name"
                        item-value="name"
                        outlined
                        placeholder="Unit"
                        v-if="productName !== ''"
                        @change="getPrice"
                      ></v-select><!-- @change="getPrice" -->

                      <v-select
                        v-model="unitName"
                        outlined
                        placeholder="Unit"
                        v-if="productName === ''"
                      ></v-select>
                    </v-col>
                  </v-row>
                  <!-- PRODUCTS & UNIT END -->

                  <!-- QTY & PRICES -->
                  <v-row
                    justify="space-between"
                  >
                    <v-col
                      cols="12"
                      md="4"
                    >
                    </v-col>

                    <v-col
                      cols="12"
                      md="2"
                    >
                      <label class="label-text">Quantity
                        <span color="red darken-3">*</span>
                      </label>
                      <v-text-field
                        v-model="quantity"
                        placeholder="Quantity"
                        outlined
                        v-on:keypress="isNumber()"
                      ></v-text-field>
                    </v-col>

                    <v-col
                      cols="12"
                      md="2"
                    >
                      <label class="label-text">Prices
                        <span color="red darken-3">*</span>
                      </label>
                      <v-text-field
                        v-model="price"
                        readonly="readonly"
                        outlined
                      ></v-text-field>
                    </v-col>

                    <v-col
                      cols="12"
                      md="4"
                    >
                      <label class="label-text right">Total Prices
                        <span color="red darken-3">*</span>
                      </label>
                      <v-text-field
                        v-model="totalPrice"
                        disabled="disabled"
                        outlined
                      ></v-text-field>

                      <v-divider></v-divider>

                      <h4 class="prices">
                        Total Nett Prices.
                        <span class="right">{{totalPrice}}</span>
                      </h4>

                    </v-col>
                  </v-row>
                  <!-- QTY & PRICES END -->
                </span>

                <!-- BUTTON NEW ITEM -->
                <v-row
                  justify="space-between"
                >
                  <v-col
                    cols="12"
                    md="4"
                  >
                  </v-col>

                  <v-col
                    cols="12"
                    md="8"
                  >
                  <v-btn
                    tile
                    depressed
                    color="warning"
                    @click="add"
                  >
                    New Item 
                    <v-icon right>
                      mdi-plus
                    </v-icon>
                  </v-btn>
                  </v-col>
                </v-row>
                <!-- BUTTON NEW ITEM END -->

                <!-- TOTAL -->
                <v-row
                  justify="space-between"
                >
                  <v-col
                    cols="12"
                    md="4"
                  >
                  </v-col>

                  <v-col
                    cols="12"
                    md="2"
                  >
                  </v-col>

                  <v-col
                    cols="12"
                    md="2"
                  >
                  </v-col>

                  <v-col
                    cols="12"
                    md="4"
                  >
                    <h3 class="prices">
                      Total
                      <span class="right">{{totalPrice}}</span>
                    </h3>

                  </v-col>
                </v-row>
                <!-- TOTAL END -->
              </v-card-text>

              <v-divider></v-divider>

              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                  text
                  depressed
                  color="black"
                >
                  Cancel
                </v-btn>

                <v-btn
                  tile
                  depressed
                  color="success"
                  style="margin-right: 25px;"
                  :disabled="employeeName == '' || dcName == '' || 
                  paymentType == '' || date == '' || notes == ''"
                >
                  Confirm
                </v-btn>
              </v-card-actions>
            </v-card>
        </v-col>
      </v-row>

      <Footer />

   </div>
</template>

<script>
  import axios from 'axios';
  import Editor from "../components/Editor";
  import Navbar from '../components/Navbar';
  import Sidebar from '../components/Sidebar';
  import Footer from '../components/Footer';

  export default {
    components: {
      Editor,
      Navbar,
      Sidebar,
      Footer
    },
    async asyncData ({ params }) {
      const { data } = await axios.get(`http://dummy.restapiexample.com/api/v1/employees`)
      return { employees: data.data }
    },
    data () {
      return {
        headTitle: "Create Order",
        itemsDC: [
          { name: 'DC Tangerang', value: 'Tangerang' },
          { name: 'DC Cikarang', value: 'Cikarang' },
        ],
        itemsPT: [
          { name: 'Cash + 1', value: 'C1' },
          { name: 'Cash + 3', value: 'C3' },
          { name: 'Cash + 7', value: 'C7' },
          { name: 'Transfer + 1', value: 'T1' },
          { name: 'Transfer + 3', value: 'T3' },
          { name: 'Transfer + 7', value: 'T7' },
        ],
        itemsProducts: [
          { id: 1, product_name: "Morning Dew Milk", 
            units: [
              { name: "pak", price: 10000 },
              { name: "pcs", price: 1000 }
            ]
          },
          { id: 2, product_name: "Le Minerale 600ml", 
            units: [
              { name: "carton", price: 250000 },
              { name: "pak", price: 50000 },
              { name: "pcs", price: 5000 }
            ]
          },
          { id: 3, product_name: "Greenfields Full Cream Milk 1L", 
            units: [
              { name: "carton", price: 500000 },
              { name: "pak", price: 250000 },
              { name: "pcs", price: 25000 }
            ]
          }
        ],
        itemsUnit: [],
        dcName: "",
        employeeName: "",
        paymentType: "",
        expiredDate: "",
        notes: "",
        productName: [],
        unitName: [],
        quantity: 0,
        price: 0,
        productIDx: [],
        date: "", //new Date().toISOString().substr(0, 10),
        disabledDates: {
          to: new Date(Date.now() - 8640000)
        },
        menu2: false,
        textFields: [0]
      }
    },
    methods: {
      getUnit() {
        console.log("aaa ", this.productName);
        this.unitName = "";
        this.price = 0;
        const selectedUnit = this.itemsProducts.filter((productID) => productID.id === this.productName);
        this.productIDx = selectedUnit[0].units;
        this.itemsUnit = selectedUnit[0].units;
      },
      getPrice(name) {
        console.log(name);
        const selectedPrice = this.productIDx.filter((unName) => unName.name === name);
        this.price = selectedPrice[0].price;
      },
      add() {
        this.textFields.push(1);
      },
      remove (index) {
        this.textFields.splice(index, 1)
      },
      validate(id) {
          
      },
      reset() {
        this.$refs.form.reset();
      },
      isNumber: function(evt) {
        evt = (evt) ? evt : window.event;
        var charCode = (evt.which) ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode != 9)) {
              evt.preventDefault();
        } else {
              return true;
        }
      },
    },
    head () {
      return {
        title: this.headTitle,
        meta: [
          {
            hid: 'description',
            name: 'description a',
            content: 'my content'
          }
        ]
      }
    },
    computed: {
      totalPrice: {
        get: function () {
          return parseInt(this.quantity) * parseInt(this.price);
        },
        set: function (newValue) {
          this.totalPrice = newValue;
        }
      },
      /*unitName: {
        get: function () {
          console.log(this.productName[0]);
          return this.itemsProducts.filter((productID) => productID.id === this.productName);
        },
        set: function (newValue) {
          var selectedUnit = newValue;
          this.productIDx = selectedUnit[0].units;
          this.itemsUnit = selectedUnit[0].units;
        }
      }*/
    }
  };
</script>

<style type="text/css">
  .btn-delete{
    margin: 40px 0px;
    width: 5px !important;
    height: 5px !important;
    padding: 10px;
    float: right
  }

  .v-input--is-disabled .v-input__slot{
    background: rgba(0,0,0,.06) !important;
  }

  .prices {
    padding: 10px 0;
    color: #000;
  }

  .title {
    padding-bottom: 20px;
    padding-left: 20px;
  }

  .right {
    float: right;
  }

  .label-text{
    color: #000;
    line-height: 20px;
  }

  .label-text span{
    color: red;
  }

  .v-input {
    width: 100%;
  }

  .v-card__text{
    padding-right: 75px;
  }

  .v-card__title{
    font-size: 1rem;
    color: #000;
    line-height: 0rem;
  }

  .v-main__wrap{
    background: #eee;
  }

  .v-card__actions{
    padding: 25px 0px;
  }
</style>