import Vue from 'vue'
import ImageUploader from 'vue-image-upload-resize'
 
Vue.use(ImageUploader)