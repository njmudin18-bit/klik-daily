import Vue from 'vue'
import Flickity from 'vue-flickity'

Vue.component('Flickity', Flickity)